Plot and Navigate a Virtual Maze

For this project following are the requirements, 
	Python 2.7
And other libraries used for this project are 
	numpy 
	As other libraries used for this projec are built in python.